package burp;

import java.util.*;
import java.io.*;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
import java.nio.charset.StandardCharsets;

import java.util.UUID;
import java.util.*;
import javax.crypto.Mac;
import javax.crypto.spec.SecretKeySpec;

public class BurpExtender implements IBurpExtender, IHttpListener {
    private static String HMAC_SECRET_KEY = "XgB5v3gpYsk14kZ9Z+giKYs2Uz74zfjyYA8Qb0dKIeT4y3pkHUDliOzTe3CA9pXanBsXX4La1Kvl8hhpJTr5KQ==";
	private IBurpExtenderCallbacks callbacks;
	private IExtensionHelpers helpers;
	private PrintWriter stdout;
	private PrintWriter stderror;
	
    @Override
    public void registerExtenderCallbacks(IBurpExtenderCallbacks callbacks) {
    	this.callbacks = callbacks;
    	this.helpers = callbacks.getHelpers();
    	this.callbacks.setExtensionName("HMAC Auto Modifier");
    	this.stdout = new PrintWriter(this.callbacks.getStdout(), true);
    	this.stderror = new PrintWriter(this.callbacks.getStderr(), true);
    	this.stdout.println("Extension is loaded successfully!");
    	this.callbacks.registerHttpListener(this);
    }
    
    @Override
    public void processHttpMessage(int toolFlag, boolean messageIsRequest, IHttpRequestResponse messageInfo) {

        if (messageIsRequest){
            String requestBody = null;
            String requestString = new String(messageInfo.getRequest());
            IRequestInfo request = helpers.analyzeRequest(messageInfo);
            if (!messageInfo.getHost().equals("2l3qfku205.execute-api.eu-central-1.amazonaws.com"))
            {
            	return;
            }
            boolean getCatalog = false;
            if(messageInfo.getUrl().getPath().equals("/TEST/v1/catalog"))
            {
            	getCatalog = true;
            }
            
            ArrayList<String> headers = (ArrayList<String>) request.getHeaders();
            requestBody = requestString.substring(request.getBodyOffset());
            
            HashMap<String,String> map = new HashMap<String,String>();

            for (Iterator<String> it=headers.iterator(); it.hasNext();)
            {
            	String header = it.next();
            	
            	if (header.startsWith("X-App_language"))
        		{
        			map.put("X-App_language", header.split("X-App_language: ")[1]);
        		} else if (header.startsWith("X-App_version"))
        		{
        			map.put("X-App_version", header.split("X-App_version: ")[1]);
        		} else if (header.startsWith("X-Caller_id"))
        		{
        			map.put("X-Caller_id", header.split("X-Caller_id: ")[1]);
        		} else if (header.startsWith("X-Channel"))
        		{
        			map.put("X-Channel", header.split("X-Channel: ")[1]);
        		} else if (header.startsWith("X-Correlation_id"))
        		{
//        			map.put("X-Correlation_id", header.split("X-Correlation_id: ")[1]);
        			// modify correlation id
        			it.remove();
        		} else if (header.startsWith("X-Session_token"))
        		{
        			map.put("X-Session_token", header.split("X-Session_token: ")[1]);
        		} else if (header.startsWith("X-User_id"))
        		{
        			map.put("X-User_id", header.split("X-User_id: ")[1]);
        		} else if (header.startsWith("X-Hmac"))
        		{
        			// remove XHmac header
        			it.remove();
        		}
            	
            }
			String uuid = UUID.randomUUID().toString();
			map.put("X-Correlation_id", uuid);

            
        	
            StringBuilder sb = new StringBuilder();
        	
        	String str2 = map.get("X-App_language");
            String str3 = map.get("X-App_version");
            String str4 = map.get("X-Caller_id");
            String str5 = map.get("X-Channel");
            String str6 = map.get("X-Correlation_id");
            String str7 = "", str8 = "";
           
            if (getCatalog)
            {
            	str7 = map.get("X-Session_token");
                str8 = map.get("X-User_id");
                if (str7.equals(null)) {
                    str7 = "";
                }
                if (str8.equals(null)) {
                    str8 = "";
                }
            }
           
            sb.append(str2);
            sb.append(str3);
            sb.append(str4);
            sb.append(str5);
            sb.append(str6);
            if (getCatalog)
            {
                sb.append(str7);
                sb.append(str8);
            }
            sb.append(request.getMethod());
//            this.stdout.println("Payload: " + sb.toString());
            
            try {
            	String hmac = generateHmac256SecretKey(sb.toString());
//                this.stdout.println("Calculated HMAC: " + hmac);
            	headers.add("X-Correlation_id: " + str6);
            	headers.add("X-Hmac: " + hmac);
            } catch (InvalidKeyException | NoSuchAlgorithmException unused) {
            	this.stderror.println("Exception white generating HMAC");
            }

            byte[] newRequest = helpers.buildHttpMessage(headers, requestBody.getBytes());
            messageInfo.setRequest(newRequest);
        }

    }
    
    private static String generateHmac256SecretKey(String str) throws NoSuchAlgorithmException, InvalidKeyException 					{
        Mac mac = Mac.getInstance("HmacSHA256");
        byte[] decodedBytes = Base64.getDecoder().decode(HMAC_SECRET_KEY);

        mac.init(new SecretKeySpec(decodedBytes, "HmacSHA256"));
        return Base64.getEncoder().encodeToString(mac.doFinal(str.getBytes(StandardCharsets.UTF_8)));
    }


}
