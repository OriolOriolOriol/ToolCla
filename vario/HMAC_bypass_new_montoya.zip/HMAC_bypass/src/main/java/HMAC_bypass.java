import burp.api.montoya.BurpExtension;
import burp.api.montoya.MontoyaApi;
import burp.api.montoya.http.handler.*;
import burp.api.montoya.http.message.HttpHeader;
import burp.api.montoya.http.message.requests.HttpRequest;
import burp.api.montoya.logging.Logging;

import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
import java.util.Base64;
import java.util.List;
import java.util.UUID;

import javax.crypto.Mac;
import javax.crypto.spec.SecretKeySpec;

import java.nio.charset.StandardCharsets;

public class HMAC_bypass implements BurpExtension,HttpHandler  {

    Logging logging;
    String HMAC_KEY = "XgB5v3gpYsk14kZ9Z+giKYs2Uz74zfjyYA8Qb0dKIeT4y3pkHUDliOzTe3CA9pXanBsXX4La1Kvl8hhpJTr5KQ==";
    
    @Override
    public void initialize(MontoyaApi api) {

        api.extension().setName("HMAC-Bypass");
        api.logging().logToOutput("Extension is loaded successfully!");
        api.http().registerHttpHandler(this);
        logging = api.logging();
    }

    @Override
    public RequestToBeSentAction handleHttpRequestToBeSent(HttpRequestToBeSent httpRequestToBeSent) {
        List<HttpHeader> HH = httpRequestToBeSent.headers();
        String method = httpRequestToBeSent.method();
        StringBuilder sb = new StringBuilder();
        String str2 = "it";                                     //x-app_language
        String str3 = "1.5.5";                                  //x-app_version
        String str4 = "ANDROID";                                //x-caller_ID
        String str5 = "";                                       //x-channel
        String str6 = UUID.randomUUID().toString();             //x-correlation_id
        String str7 = "";                                       //x-session_token
        String str8 = "";                                       //x-user_id
        String x_hmac;

        for (HttpHeader httpHeader : HH) {
            if (String.valueOf((httpHeader)).contains("X-Channel"))
                str5 = httpHeader.value();
            if (String.valueOf((httpHeader)).contains("X-Session_token"))
                str7 = httpHeader.value();
            if (String.valueOf((httpHeader)).contains("X-User_id"))
                str8 = httpHeader.value();
        }

        sb.append(str2);
        sb.append(str3);
        sb.append(str4);
        sb.append(str5);
        sb.append(str6);
        sb.append(str7);
        sb.append(str8);
        sb.append(method);

        //logging.logToOutput(sb.toString());
        //logging.logToOutput(str6);

        try {
            Mac mac = Mac.getInstance("HmacSHA256");
            mac.init(new SecretKeySpec(Base64.getDecoder().decode(HMAC_KEY), "HmacSHA256"));
            x_hmac = Base64.getEncoder().encodeToString(mac.doFinal(sb.toString().getBytes(StandardCharsets.UTF_8)));

            //logging.logToOutput(x_hmac);

        } catch (NoSuchAlgorithmException | InvalidKeyException e) {
            throw new RuntimeException(e);
        }


        HttpRequest request;
        request = httpRequestToBeSent.withUpdatedHeader("X-Correlation_id",str6).withUpdatedHeader("X-Hmac",x_hmac);


        return RequestToBeSentAction.continueWith(request);
        //return null;
    }

    @Override
    public ResponseReceivedAction handleHttpResponseReceived(HttpResponseReceived httpResponseReceived) {
        return null;
    }
}
